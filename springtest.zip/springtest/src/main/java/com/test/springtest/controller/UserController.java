package com.test.springtest.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.test.springtest.dto.ResponseDTOWrapper;
import com.test.springtest.helpers.UserHelper;


@RestController
@RequestMapping("/user")
public class UserController {

	@Autowired
	UserHelper userHelper;
	
	@PostMapping(value ="/{userId}", produces = { MediaType.APPLICATION_JSON_VALUE })
	public @ResponseBody ResponseEntity<List<ResponseDTOWrapper>> getAllCpyRghtRequestsForItem(	@PathVariable("userId") String userid, HttpServletRequest request) {
		return userHelper.getUserById(Long.valueOf(userid));
	}

}
