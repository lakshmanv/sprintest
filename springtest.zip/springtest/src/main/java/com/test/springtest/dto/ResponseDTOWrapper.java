package com.test.springtest.dto;

import com.test.springtest.dto.base.Payload;
import com.test.springtest.dto.base.ResponseDTO;

public class ResponseDTOWrapper {
	private ResponseDTO msg;
	private Payload payload;
	
	public ResponseDTOWrapper(ResponseDTO msg, Payload payload) {
		super();
		this.msg = msg;
		this.payload = payload;
	}
	
	public ResponseDTO getMsg() {
		return msg;
	}
	public void setMsg(ResponseDTO msg) {
		this.msg = msg;
	}
	public Payload getPayload() {
		return payload;
	}
	public void setPayload(Payload payload) {
		this.payload = payload;
	}
	
	
}