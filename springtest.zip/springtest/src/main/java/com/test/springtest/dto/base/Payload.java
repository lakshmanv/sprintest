package com.test.springtest.dto.base;

import java.io.Serializable;

public interface Payload extends Serializable {

}
