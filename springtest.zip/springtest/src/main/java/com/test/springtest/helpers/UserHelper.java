package com.test.springtest.helpers;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import com.test.springtest.dto.ResponseDTOWrapper;
import com.test.springtest.model.User;
import com.test.springtest.service.UserService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class UserHelper {
	
	@Autowired
	UserService userService;

	public ResponseEntity<List<ResponseDTOWrapper>> getUserById(Long userId) {
		List<Optional<User>> userOptList = userService.getUserByUserId(userId);
		List<ResponseDTOWrapper> responseDTOWrapperList = new ArrayList<>();
		responseDTOWrapperList.add(new ResponseDTOWrapper(responseDTO, userOptList));
		return new ResponseEntity<>(responseDTOWrapperList, HttpStatus.OK);
	}
	

}
