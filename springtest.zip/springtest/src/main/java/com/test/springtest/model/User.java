package com.test.springtest.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="user")
@SequenceGenerator(name="USER_SEQ", initialValue=1, allocationSize=1)
public class User {
		/**
		 * 
		 */
		private static final long serialVersionUID = -9202034494885793491L;

		
		@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="USER_SEQ")
		@Column(name="user_id")
		@Id  Long userId;
		
		@Column(name="user_name")
		private String userName;
		
		@Column(name="user_role_id")
		private String userRoleId;
		
		@Column(name="user_permission_id")
		private Long userPermissionId;

		public Long getUserId() {
			return userId;
		}

		public void setUserId(Long userId) {
			this.userId = userId;
		}

		public String getUserName() {
			return userName;
		}

		public void setUserName(String userName) {
			this.userName = userName;
		}

		public String getUserRoleId() {
			return userRoleId;
		}

		public void setUserRoleId(String userRoleId) {
			this.userRoleId = userRoleId;
		}

		public Long getUserPermissionId() {
			return userPermissionId;
		}

		public void setUserPermissionId(Long userPermissionId) {
			this.userPermissionId = userPermissionId;
		
	}

}
