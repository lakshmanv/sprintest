package com.test.springtest.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.test.springtest.model.User;

@Repository
public class UserRepository extends JpaRepository<User , Long> {
	
	@Query(value = "Select permissionId, permissionName from userPermissions a, userRole b, users c where a.permissionId = b.permissionId and a.userId = b.userId and b.roleId = a.roleId and userId = :userId" , nativeQuery = true)
	List<User> findByUserId(@Param("userId") Long UserId);
}
