package com.test.springtest.service;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.test.springtest.model.User;

@Service
public interface UserService {
	public List<User> getUserByUserId(Long userId);
}
