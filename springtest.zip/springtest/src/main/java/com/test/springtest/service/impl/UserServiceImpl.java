package com.test.springtest.service.impl;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.test.springtest.model.User;
import com.test.springtest.repository.UserRepository;
import com.test.springtest.service.UserService;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class UserServiceImpl implements UserService {

	@Autowired
	UserRepository userRepository;
	
	@Override
	@Transactional(readOnly = true)
	public List<User> getUserByUserId(Long userId) {
		// TODO Auto-generated method stub
		List<User> userData = userRepository.findByUserId(userId);
		return userData;
	}

}
